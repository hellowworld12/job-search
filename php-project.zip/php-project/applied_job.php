<?php
session_start();
include "navbar.html";
include "connection.php";

if(!isset($_SESSION['email'])){
    header('location:adminlogin1.php');
}else{
    $email = $_SESSION['email'];
    $sql = "select id from jobdetail where email='$email'";
    $res = $conn->prepare($sql);
    $res->execute();
    $job_detail = $res -> fetch(PDO::FETCH_ASSOC);
    $user_id = $job_detail['id'];
    
    $sql = "select job.name,jobdetail.email,job.job_title,job.location, apply_job.date from jobdetail, job, apply_job where apply_job.job_id=job.id and job.main_id=jobdetail.id and jobdetail.id='$user_id'";
    $res = $conn->prepare($sql);
    $res->execute();
    $jobs = $res -> fetchAll(PDO::FETCH_ASSOC);

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container">
<table class="table mt-5">
  <thead>
    <tr>
      <th scope="col">Job Title</th>
      <th scope="col">Location</th>
      <th scope="col">Employee Name</th>
      <th scope="col">Employee Email</th>
      <th scope="col">Date</th>
    </tr>
  </thead>
  <tbody>
    <?php foreach($jobs as $job){ ?>
    <tr>
      <td><?php echo $job['job_title'] ?></td>
      <td><?php echo $job['location'] ?></td>
      <td><?php echo $job['name'] ?></td>
      <td><?php echo $job['email'] ?></td>
      <td><?php echo $job['date'] ?></td>
    </tr>
    <?php } ?>
  </tbody>
</table>
</div>
</body>
</html>

    