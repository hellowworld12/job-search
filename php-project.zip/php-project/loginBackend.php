<?php
include 'connection.php';
session_start();
// if(isset($_SESSION['email'])){
//   header("location:homepage1.php");
//   exit();
// }
if($_SERVER["REQUEST_METHOD"] == "POST")
{
    
    $email = $_POST["email"];
    $password1 =$_POST["password"];
    // $password1 =md5($_POST["password"]);

// $servername = "localhost";
// $username = "root";
// $password = "webkul";
// $dbname = "project";

try {
    
  $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
  // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  $sql = $conn->prepare("SELECT * FROM `jobdetail` WHERE `email` = '$email' AND `password` = '$password1'");
  
  $sql->execute();
  $result = $sql->fetch(PDO::FETCH_ASSOC);

  // echo count($result);
  // die();
  
 
  if($result > 0){
    $role = $result['role'];
    if(count($result) ==  5)
    {
      
      session_start();
      $_SESSION['email']= $email;
      $_SESSION['id'] = $emp_id;

      // echo $_SESSION['id'];
      // die();
      if($role == "Employer")
      {
        header('location: employer.php');
      }
      else
      {
        header('location: employee.php');
      }
    }
  }
  else{
    // echo "not registered";
    echo '<div class="alert alert-danger">username and password are not matched </div>';
  }

  // header("location: signup.html?msg=New record created successfully");
 
} 
catch(PDOException $e) {
  echo $sql . "<br>" . $e->getMessage();
}
}
// $conn = null;
?>