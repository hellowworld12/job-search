<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <style>
            
            .qq{
                background-color: white;
                margin: 0 auto; 
                width:40%;
                margin-top:20px;
                padding:10px;
            }
            body{
                background-color: gray;
            }
            input{
              
            background: #fff;
            color: #525865;
            border-radius: 4px;
            border: 1px solid #d1d1d1;
            box-shadow: inset 0px 1px 8px rgba(0, 0, 0, 0.2);
            font-family: inherit;
            font-size: 1em;
            line-height: 1.45;
            outline: none;
            padding: 0.6em 1.45em 0.7em;
            -webkit-transition: .18s ease-out;
            -moz-transition: .18s ease-out;
            -o-transition: .18s ease-out;
            transition: .18s ease-out;
            }

            input:hover {
            box-shadow: inset 1px 2px 8px rgba(0, 0, 0, 0.02);
            }

            input:focus {
            color: #4b515d;
            border: 1px solid #B8B6B6;
            box-shadow: inset 1px 2px 4px rgba(0, 0, 0, 0.01), 0px 0px 8px rgba(0, 0, 0, 0.2);
            }
            select{
                margin-bottom: 60PX;
            }
            button{
        background-color: #005f7f ;
        margin-right: 100px !important;
        padding: 3px 25px 3px 25px !important;
               }

         nav{
            background-color: #00b79f;
           }
          
           
        </style>
</head>
<body>
<nav class="navbar">
        <div class="container-fluid">
            
          <a class="navbar-brand text-white"><span><img src="download.png" alt="Trulli" width="35" height="30"></span><b>JOBSTAKE</b></a>
          <form class="d-flex">
            <a href="adminlogin1.php"><button class="btn text-white btn-warning" type="submit">LOG IN</a></button>
          </form>
        </div>
      </nav>
    <div class="qq">
        <div class="form-group mx-auto col-10 col-md-8 col-lg-6">
            <h3 class="text-center"><b>SignUp Page</b></h3>
        </div>
        <form   method="POST" action="signupBackend.php" name="myForm" onsubmit="return validateForm()">

            <div class="form-group col-10 col-md-8 col-lg-12">
                <label for="name"><b>Name</b></label>
                <input type="text" name="name"  class="form-control" id="name" aria-describedby="emailHelp">
                <!-- <span class="error">* <?php echo $nameErr; ?> </span>   -->
                <!-- <small id="emailHelp" class="form-text text-muted"></small> -->
            </div>
          
            <div class="form-group col-10 col-md-8 col-lg-12">
                <label for="email"><b>Email</b></label>
                <input type="email" name="email" class="form-control" id="email" aria-describedby="emailHelp">
                <!-- <small id="emailHelp" class="form-text text-muted"></small> -->
            </div>
            <div class="form-group col-10 col-md-8 col-lg-12">
                <label for="exampleInputPassword1"><b>Password</b></label>
                <input type="password" name="pass" class="form-control" id="pass">
            </div>
            <select class="form-select col-5 col-md-8 col-lg-12 " name="role" aria-label="Default select example">
                <option value="Employee">Employee</option>
                <option value="Employer">Employer</option>
            </select>
            <div class="col-10 col11">
                <button type="submit" class="btn btn-warning text-white">SIGN UP NOW</button>
            </div>
    </div>
    </form>
    
    <script>

function validateForm(){
        var name = document.forms["myForm"]["name"].value;
        var email = document.forms["myForm"]["email"].value;
        var password= document.forms["myForm"]["pass"].value;
        

        if(name==="" || email===""|| password===""){
        alert("please fill in all fields");
        return false;

        }
        var namePattern =/^[A-Za-z\s]+$/ ;
        if(!name.match(namePattern)){
            alert("invalid name format.only alphabets are allowed");
            return false;
        }

    //      var emailPattern =/^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    //      if(!email.match(emailPattern)){
    //      alert("invalid email format");
    //      return false;
    //   }
    //   var passPattern =(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,};
    //      if(!pass.match(passPattern)){
    //      alert("invalid password format");
    //      return false ;
    //   }
      
    // alert("application submitted successfully");
    return true;
}
        </script>
</body>

</html>