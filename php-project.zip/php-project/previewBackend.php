<?php
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);


session_start();

include "connection.php";

if(isset($_SESSION["user_email"])){
$name = $_SESSION["name"];
$user_email = $_SESSION["user_email"];
$location = $_SESSION["location"];
$job= $_SESSION["job"];
$file_name = $_SESSION['file_name'];

$email = $_SESSION['email'];
$sql = "select id from jobdetail where email='$email'";
$res = $conn->prepare($sql);
$res->execute();
$job_detail = $res -> fetch(PDO::FETCH_ASSOC);
$user_id = $job_detail['id'];

$upload_image =  move_uploaded_file($file_tmp,"upload-images/".$file_name);

$sql = "INSERT INTO job  (name, email,location,job_title,main_id,upload_image)
VALUES ('$name','$user_email','$location','$job','$user_id','$file_name')";
$stmt = $conn->prepare($sql);                            
$stmt->execute();
}
$conn = null;

unset($_SESSION["user_email"]);
unset($_SESSION["name"]);
unset($_SESSION["location"]);
unset($_SESSION["job"]);
unset($_SESSION['file_name']);

 header('location: underpreview.php');

?>