<?php
session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
if(!isset($_SESSION["email"]))
{
    header('location:adminlogin1.php');
}
include "connection.php";
    $user_email = $_SESSION['email'];
    if(isset($_SESSION["user_email"])){
    $name = $_SESSION["name"];
    $email = $_SESSION["user_email"];
    $location = $_SESSION["location"];
    $job = $_SESSION["job"];
    }else{
        $name='';$email='';$location='';$job='';
    }

    $sql = "select id from jobdetail where email='$email'";
    $res = $conn->prepare($sql);
    $res->execute();
    $job_detail = $res->fetch(PDO::FETCH_ASSOC);
    
    if(!empty($job_detail)){
        $id = $job_detail['id'];
        $sql = "INSERT INTO preview (name, email,location,job_title,main_id)
        VALUES ('$name','$email','$location','$job','$id')";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
    }

    unset($_SESSION["user_email"]);
    unset($_SESSION["name"]);
    unset($_SESSION["location"]);
    unset($_SESSION["job"]);

    $sql = "SELECT * FROM `preview`; --WHERE `email`='$user_email'";
    $stmt = $conn->prepare($sql);
    $stmt->execute();

    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $sql = "SELECT * FROM `job`";
    $stmt = $conn->prepare($sql);
    $stmt->execute();

    $results1 = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $conn = null;


    include('finalpage.php');
?>