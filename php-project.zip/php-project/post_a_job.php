<?php
  require "navbar.html"  ;
  include 'connection.php';
  session_start();

 if(!isset($_SESSION['email'])){
    header('location:adminlogin1.php');
 }

  if(isset($_GET['email'])){
    $email =$_GET['email'];

    


//   $email = $_SESSION["email"];

  $sql = "SELECT * FROM `job` WHERE `email` = '$email'";
  $stmt = $conn->prepare($sql);
 
  $stmt->execute();
  $result = $stmt->fetch(PDO::FETCH_ASSOC);

  
//   print_r($result);
//   die();

  }
  ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <style> 
            .qq{
                background-color: white;
                margin: 0 auto; 
                width:40%;
                margin-top:15px;
                padding: 10px;
            }
            body{
                background-color: gray;
            }
            input{
              
              background: #fff;
              color: #525865;
              border-radius: 4px;
              border: 1px solid #d1d1d1;
              box-shadow: inset 0px 1px 8px rgba(0, 0, 0, 0.2);
              font-family: inherit;
              font-size: 1em;
              line-height: 1.45;
              outline: none;
              padding: 0.6em 1.45em 0.7em;
              -webkit-transition: .18s ease-out;
              -moz-transition: .18s ease-out;
              -o-transition: .18s ease-out;
              transition: .18s ease-out;
              }
  
              input:hover {
              box-shadow: inset 1px 2px 8px rgba(0, 0, 0, 0.02);
              }
  
              input:focus {
              color: #4b515d;
              border: 1px solid #B8B6B6;
              box-shadow: inset 1px 2px 4px rgba(0, 0, 0, 0.01), 0px 0px 8px rgba(0, 0, 0, 0.2);
              }
               
        </style>
</head>
<body>
    
    <div class="qq">
        <div class="form-group mx-auto col-10 col-md-8 col-lg-6">
            <h3 class="text-center"><b>POST A JOB</b></h3>
        </div>
        <form method ="POST" action="preview.php" enctype="multipart/form-data"  name="myForm" onsubmit="return validateForm()">
            <div class="form-group col-10 col-md-8 col-lg-12">
                <label for="exampleInputEmail1"><b>Name</b></label>
                <input type="text" name="name" value="<?php echo !empty($_SESSION['name']) ? $_SESSION['name']:"";?>" class="form-control" id="name" aria-describedby="emailHelp">
                <small id="emailHelp" class="form-text text-muted"></small>
            </div>
            <div class="form-group col-10 col-md-8 col-lg-12">
                <label for="exampleInputPassword1"><b>Email</b></label>
                <input type="email" name="email" value="<?php echo !empty($_SESSION['user_email']) ? $_SESSION['user_email']:""?>" class="form-control" id="email">
            </div>
            <div class="form-group col-10 col-md-8 col-lg-12">
                <label for="exampleInputlocation"><b>Location</b></label>
                <input type="text" name="location" value="<?php echo !empty($_SESSION['location']) ? $_SESSION['location']:""?>" class="form-control" id="exampleInputPassword11">
            </div>
            <div class="form-group col-10 col-md-8 col-lg-12">
                <label for="comment" ><b>Job Title</b></label>
                <textarea class="form-control"name="job"  rows="5" id="comment"><?php echo !empty($_SESSION['job']) ? $_SESSION['job']:"";?></textarea>
            </div>
            <!-- <div class="form-group col-10 col-md-8 col-lg-10"> -->
            <!-- <div class="btn btn-info text-white"> -->
                <input type="file" name="image" type="submit">
                <!-- <b>UPLOAD A THUMBNAIL IMAGE</b></div> -->
        <!-- </div> -->
           
            <div class="form-group col-10 col-md-8 col-lg-10 mt-4">
            <button type="submit" class="btn btn-warning text-white"><b>PREVIEW POST</b></button>
         </div>       
         </form>
    </div>
   <script>

    function validateForm(){
        var name = document.forms["myForm"]["name"].value;
        var email = document.forms["myForm"]["email"].value;
        var location= document.forms["myForm"]["location"].value;
        var jobTile = document.forms["myForm"]["job"].value;

        if(name==="" || email===""|| location===""|| jobTitle===""){
        alert("please fill in all fields");
        return false;

        }
        var namePattern =/^[A-Za-z\s]+$/ ;
        if(!name.match(namePattern)){
            alert("invalid name format.only");
            return false;
        }

         var emailPattern =/^[^\s@]+@[^\s@]+\.[^\s@]+$/;
         if(!email.match(emailPattern)){
         alert("invalid email format");
         return false;
    }
    alert("application submitted successfully");
    return true;
}

    </script>
</body>

</html>