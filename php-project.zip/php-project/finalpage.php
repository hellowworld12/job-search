<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  session_start();
  $name = $_POST["name"];
  $email = $_POST["email"];
  $location = $_POST["location"];
  $job = $_POST["job"];

  $_SESSION['id'] =$id;
  $_SESSION["name"] = $name;
  $_SESSION["email"] = $email;
  $_SESSION["location"] = $location;
  $_SESSION["job"] = $job;
  // echo $_SESSION['job'];
  // die();


}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css"
    integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <style>
    button {
      background-color: #005f7f;

      margin-right: 100px !important;
      padding: 3px 25px 3px 25px !important;
    }

    nav {
      background-color: #00b79f;
    }

    .sear {
      padding-right: 350px;

    }

    .cls {
      margin-left: 30px;
    }

    .photo1 {
      display: flex;
      justify-content: space-between;
      border: 2px solid gray;
      padding: 10px;
      margin: auto;
      margin-top: 10px;
      width: 800px;
      
    }

    h4 {
      color: blue;

    }
    span {
      margin-left: 80px;
    }
    .mar{
      margin-left: 250px;
    }
    /* .scroll{
    overflow-y: scroll; 
    }
  */
  .scroll-y {
    height: 500px;
    overflow-y: scroll;
    width: fit-content;
}

  </style>
</head>

<body>
  <nav class="navbar">
    <div class="container-fluid">

      <a class="navbar-brand text-white mx-auto col-lg-4"><span><img src="images/download.png" alt="Trulli" width="35"
            height="30"></span><b>JOBSTAKE</b></a>
      <form class="d-flex">
        <button class="btn text-white col-lg-6 bg-warning"><a href="logout.php">LOG OUT</a></button>

      </form>
    </div>
  </nav>
  <nav class="navbar navbar-light bg-info mx-auto col-lg-8 pt-4 pb-4">
    <div class="container-fluid">
      <form class="d-flex">
        <input class="form-control me-2 sear" type="search" placeholder="Search for Job here" aria-label="Search">
        <button class="btn btn-outline-success bg-warning text-white cls " type="submit">SEARCH FOR JOBS</button>

      </form>
    </div>
  </nav>


  <div class="text-center">
    <button type="button" class="btn btn-primary my-3">post under review</button>
  </div>
  <section class="d-flex justify-content-center">
  <div class="col-md-8 scroll-y border">
  <?php
  foreach ($results as $get) { ?>
  <div class="scroll">
    <div class="photo1">
      <div class="photo">
        <p><img src="<?php echo 'upload-images/'.$get['upload_image'] ?>" alt="Pineapple" style="width:170px;height:170px;margin-right:15px;">
      </div>
      <div class="photo2">
        <h4>Job Title For This Awesome Post Simply Goes Here</h4><br>
        <p class="mb-0"><b>posted by-</b><?php echo $get['name'] ?></p>
        <!-- <p class="mb-0"><b>posted on- </b></p> -->
        <p class="mb-0"><b> location-</b><?php echo $get['location'] ?></p>
        <p class="mb-0"><b> Contact Email-</b><?php echo $get['email'] ?></p>
        <p class="mb-0"><b>Job Title-</b><?php echo $get['job_title'] ?></p>
        <button class="btn text-white col-sm-3 bg-warning mar"><a href="publish.php?id=<?php echo $get['id']; ?>">Publish post</a></button>
      </div>
    </div>
      <form class="d-flex" >
            <!-- <button class="btn text-white col-sm-1 bg-warning "><a href="post_a_job.php?email= ?>">Edit Post</a></button> -->  
        </form> 
  </div>
  <?php } ?>
  </div>
  </section>






  <div class="text-center">
    <button type="button" class="btn btn-primary my-3">published posts</button>
  </div>

  <section>
  <div class="d-flex justify-content-center">
    <div class="col-md-8 scroll-y border">
    <?php
  foreach ($results1 as $get1) { ?>
  <div class="photo1">
    <div class="photo">
      <p><img src="<?php echo 'upload-images/'.$get1['upload_image'] ?>" alt="Pineapple" style="width:170px;height:170px;margin-right:15px;">
  </div>
  <div class="photo2">
  <h4>Job Title For This Awesome Post Simply Goes Here</h4><br>
        <p class="mb-0"><b>posted by-</b><?php echo $get1['name'] ?></p>
        <!-- <p class="mb-0"><b>posted on- </b></p> -->
        <p class="mb-0"><b> location-</b><?php echo $get1['location'] ?></p>
        <p class="mb-0"><b> Contact Email-</b><?php echo $get1['email'] ?></p>
        <p class="mb-0"><b>Job Title-</b><?php echo $get1['job_title'] ?></p>
      <button class="btn text-white col-sm-3 bg-warning mar"><a href="unpublish.php?id=<?php echo $get1['id']; ?>">Unpublish post</a></button>
    </div>
  </div>
  <?php } ?>
    </div>
  </div>
  </section>


</body>

</html>