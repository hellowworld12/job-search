<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

 session_start();
 if(!isset($_SESSION['email'])){
    header('location:adminlogin1.php');
 }
 
  $id = $_GET['id'];
 include "connection.php";

 $sql = "SELECT * FROM `job` WHERE `id` = '$id'";
 $stmt = $conn->prepare($sql);
 $stmt -> execute();

 $result = $stmt -> fetch(PDO::FETCH_ASSOC);
//  print_r($result);
//  die();
$name = $result['name'];
$email= $result['email'];
$location = $result['location'];
$job_title = $result['job_title'];
$file_name = $result['upload_image'];

 //get user id
 $email = $_SESSION['email'];
 $sql = "select id from jobdetail where email='$email'";
 $res = $conn->prepare($sql);
 $res->execute();
 $job_detail = $res->fetch(PDO::FETCH_ASSOC);
 if(!empty($job_detail)){
     $main_id = $job_detail['id'];
 }else{
     $main_id = '';
 }



$sql1 = "INSERT INTO `preview`(`name`, `email`,`location`,`job_title`,`main_id`,`upload_image`)VALUES ('$name','$email','$location','$job_title','$main_id','$file_name')";
$stmt1 = $conn->prepare($sql1);
$a = $stmt1 -> execute();
// echo $a;
// die();

$sql2 = "DELETE FROM `job` WHERE `id` = '$id'";
$stmt2 = $conn->prepare($sql2);
$stmt2 -> execute();

header("location:underpreview.php");
?>

 