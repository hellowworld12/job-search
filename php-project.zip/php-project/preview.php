<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require "navbar.html";
include 'connection.php';
session_start();
if(!isset($_SESSION['email'])){
    header("location:adminlogin1.php");
}
if($_SERVER["REQUEST_METHOD"] == "POST")
{
    //get user id
    $email = $_SESSION['email'];
    $sql = "select id from jobdetail where email='$email'";
    $res = $conn->prepare($sql);
    $res->execute();
    $job_detail = $res->fetch(PDO::FETCH_ASSOC);
    if(!empty($job_detail)){
        $user_id = $job_detail['id'];
    }else{
        $user_id = '';
    }


    $name = $_POST["name"];
    $post_email = $_POST["email"];
    $location=$_POST["location"];
    $job=$_POST["job"]; 
    
    $_SESSION['name'] = $name;
    $_SESSION['user_email'] = $post_email;
    $_SESSION['location'] = $location;
    $_SESSION['job'] = $job;
    
    if(isset($_FILES['image'])){
        $file_name = $_FILES['image']['name'];
        $file_size = $_FILES['image']['size'];
        $file_tmp = $_FILES['image']['tmp_name'];
        $file_type = $_FILES['image']['type'];

        $_SESSION['file_name'] =  $file_name;
     
        $upload_image =  move_uploaded_file($file_tmp,"upload-images/".$file_name);
        // $query = "INSERT INTO `job`(`name`, `email`, `location`, `job_title`, `main_id`,`upload_image`) VALUES('$name','$post_email','$location','$job','$user_id','$file_name')";
        // $stmt = $conn->prepare($query);
        // $stmt->execute();
     }
}
// $sql = "select * from job order by id desc limit 1";
// $stmt=$conn->prepare($sql);
// $stmt->execute();
// $results = $stmt -> fetch(PDO::FETCH_ASSOC);


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    .buttons {
        width: 200px;
        margin: 0 auto;
        display: inline;}
        
     .action_btn {
        width: 200px;
        margin: 0 auto;
        display: inline;
        }
        button{
            float: right;
            margin-top: 10px;
            background-color: #ff9c00;
            border: none;
            color: white;
            
        }
        .photo{
            border:2px solid gray;
            height:200px;
            margin:auto;
            width:800px;
        }
        img {
           float: left;
            }
            h4{
                color:blue;

            }
            /* .button1{
        background-color: #005f7f ;
        padding: 3px 25px 3px 25px !important;
               } */

         nav{
            background-color: #00b79f;
           }
            /* p{
                margin-left:280px;
               
            } */
</style>
<body>
        <div class="buttons">
        <div class="action_btn"> 
        <button><a href="underpreview.php">UNDER PREVIEW</a></button>    
        <button><a href="previewBackend.php">PUBLISH POST</a></button>
        <?php if(isset($_SESSION['user_email'])){ ?>
        <button name="submit" type="submit"><a href="post_a_job.php?email=<?php echo $_SESSION['user_email']; ?>">EDIT POST</a></button>
        <?php }else{?>
            <button name="submit" type="submit"><a href="post_a_job.php">Post A Job</a></button>
        <?php } ?>
    </div>
<br><br><br><br> 
<?php if(isset($_SESSION['user_email'])){ ?>               
      <div class="photo">
      <p><img src="upload-images/<?php echo $file_name ; ?>" alt="Pineapple" style="width:170px;height:170px;margin-right:15px;">
      <h4>Job Title For This Awesome Post Simply Goes Here</h4><br>
      <b>posted by-</b><?php echo $_SESSION['name'] ?>  <br>
      <span><b> location-</b><?php echo $_SESSION['location'] ?></span><br>
      <b> Contact Email-</b><?php echo $_SESSION['user_email']?><br>
      <b>Job Title-</b><?php echo $_SESSION['job']?>
        </div>
<?php } ?>  
        <!-- </div></div><br><br><br><br> 
        <p> you can edit your post  only here before publishing here</p>    
       -->
</body>
</html>