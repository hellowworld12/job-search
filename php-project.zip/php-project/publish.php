<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL); 

 session_start();

//  if(!isset($_SESSION['email'])){
//     header("location:adminlogin1.php");
//   } 
 
 $id = $_GET['id'];
 include "connection.php";

 $sql = "SELECT * FROM `preview` WHERE `id` = '$id'";
 $stmt = $conn->prepare($sql);
 $stmt -> execute();

 //get user id
 $email = $_SESSION['email'];
 $sql = "select id from jobdetail where email='$email'";
 $res = $conn->prepare($sql);
 $res->execute();
 $job_detail = $res->fetch(PDO::FETCH_ASSOC);
 if(!empty($job_detail)){
     $main_id = $job_detail['id'];
 }else{
     $main_id = '';
 }

$result = $stmt -> fetch(PDO::FETCH_ASSOC);
$name = $result['name'];
$post_email= $result['email'];
$location = $result['location'];
$job_title = $result['job_title'];
$file_name = $result['upload_image'];



$sql1 = "INSERT INTO `job`(`name`, `email`, `location`, `job_title`, `main_id`,`upload_image`) VALUES('$name','$post_email','$location','$job_title','$main_id','$file_name')";
$stmt1 = $conn->prepare($sql1);
$stmt1->execute();

$sql2 = "DELETE FROM `preview` WHERE `id` = '$id'";
$stmt2 = $conn->prepare($sql2);
$stmt2 -> execute();


header('location:underpreview.php');
?>

 