<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start(); 

 include "connection.php";
 $msg='';
 
 $email = $_SESSION['email'];   
 $sql = "select id from jobdetail where email='$email'";
 $res = $conn->prepare($sql);
 $res->execute();
 $result = $res -> fetch(PDO::FETCH_ASSOC);

 if($_SERVER["REQUEST_METHOD"] == "POST"){
      $job_id = $_POST['job_id'];
      $user_id = $result['id'];
      $name = $_POST['name'];
      $user_email = $_POST['user_email'];

      $insert = "INSERT INTO `apply_job`(`job_id`, `user_id`,`name`, `email`) VALUES('$job_id','$user_id','$name','$user_email')";
      $stmt = $conn->prepare($insert);
      $stmt->execute();
      
      if($stmt){
          $msg = "Successfully applied form";
      }else{
          $msg = "Applied failed";
      }

      header('location:employee.php');
}

?>
