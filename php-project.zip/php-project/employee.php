<?php
session_start();
if(!isset($_SESSION['email'])){
  header('location:adminlogin1.php');
}
ini_set('display_errors', 1);
error_reporting(E_ALL);

include 'connection.php';

$sql = "SELECT * FROM `job`";
$stmt = $conn->prepare($sql);                            
$stmt->execute();
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

$email = $_SESSION['email'];   
$sql = "select id from jobdetail where email='$email'";
$res = $conn->prepare($sql);
$res->execute();
$result = $res -> fetch(PDO::FETCH_ASSOC);
$user_id = $result['id'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css"
    integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <style>
        button{
        background-color: #005f7f ;
        margin-right: 100px !important;
        padding: 3px 25px 3px 25px !important;
               }

         nav{
            background-color: #00b79f;
           }
           .sear{
            padding-right: 350px;
           
           }
           .cls{
            margin-left: 30px;
           }
           .photo{
            border:2px solid gray;
            height:180px;
            margin:auto;
            margin-top: 10px;
            width:800px;
        }
        .img1{
           float: left;
            }
            h4{
                color:blue;

            }
            span{
                margin-left:80px;
            }
           
          
    </style>
</head>

<body>
    <nav class="navbar">
        <div class="container-fluid">
            
          <a class="navbar-brand text-white mx-auto col-lg-8"><span><img src="download.png" alt="Trulli" width="35" height="30"></span><b>JOBSTAKE</b></a>
          <form class="d-flex">
            <button class="btn text-white col-lg-7 bg-warning"><a href="logout.php">LOG OUT</a></button>
          </form>
        </div>
      </nav>
      <nav class="navbar navbar-light bg-info mx-auto col-lg-8 pt-4 pb-4">
        <div class="container-fluid">
          <form method="GET" action="search.php" class="d-flex">
            <input type="text" name="query" class="form-control me-2 sear" type="search" placeholder="Search for Job here" aria-label="Search">
           <a href="search.php"> <button class="btn btn-outline-success bg-warning text-white cls " type="submit">SEARCH FOR JOBS</button></a>
           
          </form>
        </div>
      </nav>

      
      <?php
      foreach($results as $get)
      {
      ?>
      <div class="photo">
        <p class="img1"><img src="<?php echo 'upload-images/'.$get['upload_image'] ?>" alt="Pineapple" style="width:170px;height:170px;margin-right:15px;">
        <h4></h4><br>
        <b>posted by-</b><?php echo $get['name']?> <br> <!-- name is here column name -->
        <!-- <b>posted on- </b><?php echo $get[''] ?><span><b> location-</b><?php echo $get['location'] ?></span><br> -->
        <b> Contact Email-</b><?php echo $get['email'] ?><br>
        <b>Job Title-</b><?php echo $get['job_title'] ?>
        
        <?php 
          $job_id = $get['id'];
          $sql = "select * from apply_job where job_id='$job_id' and user_id='$user_id' ";
          $stmt = $conn->prepare($sql);
          $stmt->execute();
          $res1 = $stmt->fetch(PDO::FETCH_ASSOC);

          //foreach($res1 as $applied){
            if((!empty($res1['user_id'])==$user_id) && !empty(($res1['job_id'])==$job_id)){ ?>
              <button class="btn btn-success">Applied</button>
            <?php  }
            else{?>
            <button class="btn text-white col-lg-2 bg-warning">
              <a href="applyform.php?job_id=<?php echo $get['id']?>">apply here</a>
            </button>
          <?php  }
           ?>
      </div>
       
      <?php } ?>
</body>
</html>