<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include 'connection.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {

  $name = $_POST["name"];
  $email = $_POST["email"];
  $password1 = $_POST["pass"];
  $role = $_POST["role"];

  $stmt = $conn->prepare("SELECT COUNT(*) FROM jobdetail WHERE email= :email");
  $stmt->bindParam(':email', $email);
  $stmt->execute();

  $count = $stmt->fetchColumn();
  if ($count > 0) {
    echo "<b> Sorry this Email already exits</b>";
  } else {

    $sql = "INSERT INTO jobdetail (name, email,password,role)
    VALUES ('$name','$email','$password1','$role')";

    $stmt = $conn->prepare($sql);
    $stmt->execute();
    // echo "<b> application submitted successfully</b>";
    header('location:adminlogin1.php');
  }

}
$conn = null;
?>